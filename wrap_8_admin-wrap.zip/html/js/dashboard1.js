/*
Template Name: Admin Pro Admin
Author: Wrappixel
Email: niravjoshi87@gmail.com
File: js
*/
localStorage.setItem("tst","miku");
$(function() {
    "use strict";
    // ============================================================== 
    // Our Visitor
    // ============================================================== 
	// input form localStorage.setItem("dt", JSON.stringify(jsonfile));
	//year statistics
	
	

	
	//localStorage.setItem("dt", JSON.stringify(jsonfile));
	// a = total
	var y1a = 0
	var y2a = 0
	var y3a = 0
	var y4a = 0
	var y5a = 0
	var y6a = 0
	var y7a = 0
	// b = vreified
	var y1b = 0
	var y2b = 0
	var y3b = 0
	var y4b = 0
	var y5b = 0
	var y6b = 0
	var y7b = 0
	// c = most related, score > 1.5
	var y1c = 0
	var y2c = 0
	var y3c = 0
	var y4c = 0
	var y5c = 0
	var y6c = 0
	var y7c = 0
	//localStorage.setItem("tst","hekko");
	alert(localStorage["tst"]);
	
	var input_data = JSON.parse(localStorage["dt"]);
	var nake_data = input_data["response"]["docs"];
	
	//alert(nake_data[0]["verified"]);
	for (var i = 0; i < nake_data.length; i++) {
		
		var cts = nake_data[i]["created_at"][0];
		
		var ct = String(cts).substr(0,4);
		
		if (ct == "2019") {
			y1a+=1;
			if (nake_data[i]["verified"][0] == true) {
				y1b+=1;
			}
			if (nake_data[i]["score"] > 1.5) {
				y1c+=1;
			}
		}
		if (ct == "2018") {
			y2a+=1;
			if (nake_data[i]["verified"][0] == true) {
				y2b+=1;
			}
			if (nake_data[i]["score"] > 1.5) {
				y2c+=1;
			}
		}
		if (ct == "2017") {
			y3a+=1;
			if (nake_data[i]["verified"][0] == true) {
				y3b+=1;
			}
			if (nake_data[i]["score"] > 1.5) {
				y3c+=1;
			}
		}
		if (ct == "2016") {
			y4a+=1;
			if (nake_data[i]["verified"][0] == true) {
				y4b+=1;
			}
			if (nake_data[i]["score"] > 1.5) {
				y4c+=1;
			}
		}
		if (ct == "2015") {
			y5a+=1;
			if (nake_data[i]["verified"][0] == true) {
				y5b+=1;
			}
			if (nake_data[i]["score"] > 1.5) {
				y5c+=1;
			}
		}
		if (ct == "2014") {
			y6a+=1;
			if (nake_data[i]["verified"][0] == true) {
				y6b+=1;
			}
			if (nake_data[i]["score"] > 1.5) {
				y6c+=1;
			}
		}
		if (ct == "2013") {
			y7a+=1;
			if (nake_data[i]["verified"][0] == true) {
				y7b+=1;
			}
			if (nake_data[i]["score"] > 1.5) {
				y7c+=1;
			}
		}
		
	}
	
	// country
	var pt_num = 0;
	var en_num = 0;
	var hi_num = 0;
	var oth_num = 0;
	
	for (var i = 0; i < nake_data.length; i++) {
		if (nake_data[i]["lang"][0] == "pt") {
			pt_num+=1;
		}
		else if (nake_data[i]["lang"][0] == "en") {
			en_num+=1;
		}
		else if (nake_data[i]["lang"][0] == "hi") {
			hi_num+=1;
		}
		else {
			oth_num+=1;
		}
	}
	
	
    var chart = c3.generate({
        bindto: '#visitor',
        data: {
            columns: [
                ['Other', oth_num],
                ['Brazil', pt_num],
                ['India', hi_num],
                ['USA', en_num],
            ],

            type: 'donut',
            onclick: function(d, i) { console.log("onclick", d, i); },
            onmouseover: function(d, i) { console.log("onmouseover", d, i); },
            onmouseout: function(d, i) { console.log("onmouseout", d, i); }
        },
        donut: {
            label: {
                show: false
            },
            title: "Country",
            width: 20,

        },

        legend: {
            hide: true
            //or hide: 'data1'
            //or hide: ['data1', 'data2']
        },
        color: {
            pattern: ['#eceff1', '#24d2b5', '#6772e5', '#20aee3']
        }
    });
    // ============================================================== 
    // Our Income
    // ==============================================================
    var chart = c3.generate({
        bindto: '#income',
        data: {
            columns: [
                ['Growth Income', 100, 200, 100, 300],
                ['Net Income', 130, 100, 140, 200]
            ],
            type: 'bar'
        },
        bar: {
            space: 0.2,
            // or
            width: 15 // this makes bar width 100px
        },
        axis: {
            y: {
                tick: {
                    count: 4,

                    outer: false
                }
            }
        },
        legend: {
            hide: true
            //or hide: 'data1'
            //or hide: ['data1', 'data2']
        },
        grid: {
            x: {
                show: false
            },
            y: {
                show: true
            }
        },
        size: {
            height: 290
        },
        color: {
            pattern: ['#24d2b5', '#20aee3']
        }
    });

    // ============================================================== 
    // Sales Different
    // ============================================================== 

    var chart = c3.generate({
        bindto: '#sales',
        data: {
            columns: [
                ['One+', 50],
                ['T', 60],
                ['Samsung', 20],

            ],

            type: 'donut',
            onclick: function(d, i) { console.log("onclick", d, i); },
            onmouseover: function(d, i) { console.log("onmouseover", d, i); },
            onmouseout: function(d, i) { console.log("onmouseout", d, i); }
        },
        donut: {
            label: {
                show: false
            },
            title: "",
            width: 18,

        },
        size: {
            height: 150
        },
        legend: {
            hide: true
            //or hide: 'data1'
            //or hide: ['data1', 'data2']
        },
        color: {
            pattern: ['#eceff1', '#24d2b5', '#6772e5', '#20aee3']
        }
    });
    // ============================================================== 
    // Sales Prediction
    // ============================================================== 

    var chart = c3.generate({
        bindto: '#prediction',
        data: {
            columns: [
                ['data', 91.4]
            ],
            type: 'gauge',
            onclick: function(d, i) { console.log("onclick", d, i); },
            onmouseover: function(d, i) { console.log("onmouseover", d, i); },
            onmouseout: function(d, i) { console.log("onmouseout", d, i); }
        },

        color: {
            pattern: ['#ff9041', '#20aee3', '#24d2b5', '#6772e5'], // the three color levels for the percentage values.
            threshold: {
                //            unit: 'value', // percentage is default
                //            max: 200, // 100 is default
                values: [30, 60, 90, 100]
            }
        },
        gauge: {
            width: 22,
        },
        size: {
            height: 120,
            width: 150
        }
    });
    setTimeout(function() {
        chart.load({
            columns: [
                ['data', 10]
            ]
        });
    }, 1000);

    setTimeout(function() {
        chart.load({
            columns: [
                ['data', 50]
            ]
        });
    }, 2000);

    setTimeout(function() {
        chart.load({
            columns: [
                ['data', 70]
            ]
        });
    }, 3000);

    // ============================================================== 
    // Sales chart
    // ============================================================== 
    Morris.Area({
        element: 'sales-chart',
        data: [{
                period: '2013',
                Sales: y7a,
                Earning: y7b,
                Marketing: y7c
            }, {
                period: '2014',
                Sales: y6a,
                Earning: y6b,
                Marketing: y6c
            }, {
                period: '2015',
                Sales: y5a,
                Earning: y5b,
                Marketing: y5c
            }, {
                period: '2016',
                Sales: y4a,
                Earning: y4b,
                Marketing: y4c
            }, {
                period: '2017',
                Sales: y3a,
                Earning: y3b,
                Marketing: y3c
            }, {
                period: '2018',
                Sales: y2a,
                Earning: y2b,
                Marketing: y2c
            },
            {
                period: '2019',
                Sales: y1a,
                Earning: y1b,
                Marketing: y1c
            }
        ],
        xkey: 'period',
        ykeys: ['Sales', 'Earning', 'Marketing'],
        labels: ['Total', 'Verified', 'Most Close'],
        pointSize: 0,
        fillOpacity: 0,
        pointStrokeColors: ['#20aee3', '#24d2b5', '#6772e5'],
        behaveLikeLine: true,
        gridLineColor: '#e0e0e0',
        lineWidth: 3,
        hideHover: 'auto',
        lineColors: ['#20aee3', '#24d2b5', '#6772e5'],
        resize: true

    });

//localStorage.clear();
});